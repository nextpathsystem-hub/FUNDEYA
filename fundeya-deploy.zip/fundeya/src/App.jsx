import { useState, useEffect, useRef } from "react";

const SUPABASE_URL = "https://svdidjojgbgsridjabbe.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2ZGlkam9qZ2Jnc3JpZGphYmJlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI0NTQ5NDUsImV4cCI6MjA5ODAzMDk0NX0.VDJWsovquaGKiDX4YTa_841uZ8X5UEENwlup-KKiFoE";

const api = async (path, options = {}) => {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${options.token || SUPABASE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation",
      ...options.headers,
    },
    ...options,
  });
  if (!res.ok) { const err = await res.json().catch(() => ({})); throw new Error(err.message || res.statusText); }
  return res.status === 204 ? null : res.json();
};

const authApi = async (path, body) => {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/${path}`, {
    method: "POST",
    headers: { "apikey": SUPABASE_KEY, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (data.error || data.error_description) throw new Error(data.error_description || data.error);
  return data;
};

const C = {
  navy: "#1B2B4B", navyL: "#243659", teal: "#2D9E7A", tealL: "#E8F7F2",
  orange: "#E8922A", orangeL: "#FEF3E4", gray: "#F4F5F7", grayM: "#E8E9EC",
  grayT: "#8A8F9C", text: "#1A1D23", textS: "#5A5F6B", white: "#FFFFFF",
};

const GOALS_OPTIONS = ["Révisions", "Apprendre le ML", "Monter une startup", "Préparer entretiens", "Mémorisation", "Projets créatifs", "Langues", "Sport & bien-être"];
const MOODS = { "En forme": "#2D9E7A", "Motivé·e": "#1B2B4B", "Stressé·e": "#E8922A", "Fatigué·e": "#6B7FC4", "Pas au top": "#C94B4B" };
const LEVELS = ["L1", "L2", "L3", "M1", "M2", "BUT 1", "BUT 2", "BUT 3", "Doctorat"];
const FIELDS = ["Chimie-Biologie", "Droit", "Informatique", "Éco-Gestion", "Médecine", "Pharmacie", "Psychologie", "Lettres", "Sciences", "Génie civil", "Marketing"];

const Av = ({ name = "?", color, sz = 40, online = false }) => {
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const colors = ["#2D9E7A", "#1B2B4B", "#7B5EA7", "#E8922A", "#C94B4B", "#6B7FC4"];
  const bg = color || colors[name.charCodeAt(0) % colors.length];
  return (
    <div style={{ position: "relative", width: sz, height: sz, flexShrink: 0 }}>
      <div style={{ width: sz, height: sz, borderRadius: "50%", background: bg, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 600, fontSize: sz * 0.36 }}>{initials}</div>
      {online && <div style={{ position: "absolute", bottom: 1, right: 1, width: 10, height: 10, borderRadius: "50%", background: "#2D9E7A", border: "2px solid #fff" }} />}
    </div>
  );
};

const Nav = ({ active, set }) => (
  <div style={{ display: "flex", borderTop: `1px solid ${C.grayM}`, background: C.white, padding: "8px 0 4px", flexShrink: 0 }}>
    {[["accueil", "ti-home", "Accueil"], ["decouvrir", "ti-users", "Découvrir"], ["messages", "ti-message", "Messages"], ["profil", "ti-user", "Profil"]].map(([id, ic, lb]) => (
      <button key={id} onClick={() => set(id)} style={{ flex: 1, background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "4px 0", color: active === id ? C.navy : C.grayT }}>
        <i className={`ti ${ic}`} style={{ fontSize: 22 }} />
        <span style={{ fontSize: 10, fontWeight: active === id ? 500 : 400 }}>{lb}</span>
        {active === id && <div style={{ width: 4, height: 4, borderRadius: "50%", background: C.navy }} />}
      </button>
    ))}
  </div>
);

const Input = ({ label, ...props }) => (
  <div style={{ marginBottom: 14 }}>
    {label && <p style={{ margin: "0 0 6px", fontSize: 13, fontWeight: 500, color: C.textS }}>{label}</p>}
    <input style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1.5px solid ${C.grayM}`, fontSize: 14, color: C.text, background: C.gray, outline: "none", boxSizing: "border-box" }} {...props} />
  </div>
);

const AuthScreen = ({ onAuth }) => {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handle = async () => {
    setError(""); setLoading(true);
    try {
      if (mode === "login") {
        const data = await authApi("token?grant_type=password", { email, password });
        onAuth(data.access_token, data.user);
      } else {
        const data = await authApi("signup", { email, password, data: { name } });
        if (data.access_token) {
          await api("profiles", { method: "POST", token: data.access_token, body: JSON.stringify({ id: data.user.id, name, university: "Nantes Université" }) });
          onAuth(data.access_token, data.user, name);
        } else {
          setError("Vérifie ton email pour confirmer ton compte.");
        }
      }
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: "40px 24px 24px" }}>
      <div style={{ marginBottom: 32 }}>
        <div style={{ width: 52, height: 52, borderRadius: 16, background: C.navy, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
          <i className="ti ti-users" style={{ fontSize: 26, color: "#fff" }} />
        </div>
        <h1 style={{ margin: "0 0 6px", fontSize: 26, fontWeight: 700, color: C.text }}>Fundeya</h1>
        <p style={{ margin: 0, fontSize: 14, color: C.grayT }}>Trouve ton binôme idéal à Nantes</p>
      </div>
      <div style={{ display: "flex", background: C.gray, borderRadius: 12, padding: 4, marginBottom: 24 }}>
        {[["login", "Connexion"], ["signup", "Inscription"]].map(([m, l]) => (
          <button key={m} onClick={() => setMode(m)} style={{ flex: 1, padding: "9px", borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 500, fontSize: 14, background: mode === m ? C.white : "none", color: mode === m ? C.navy : C.grayT }}>{l}</button>
        ))}
      </div>
      {mode === "signup" && <Input label="Ton prénom et nom" placeholder="Grace Kabondo" value={name} onChange={e => setName(e.target.value)} />}
      <Input label="Email" type="email" placeholder="grace@etu.univ-nantes.fr" value={email} onChange={e => setEmail(e.target.value)} />
      <Input label="Mot de passe" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
      {error && <p style={{ color: "#C94B4B", fontSize: 13, marginBottom: 14, padding: "10px 12px", background: "#FEF0F0", borderRadius: 8 }}>{error}</p>}
      <button onClick={handle} disabled={loading} style={{ width: "100%", background: C.navy, color: "#fff", border: "none", borderRadius: 12, padding: "13px", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>{loading ? "Chargement..." : mode === "login" ? "Se connecter" : "Créer mon compte"}</button>
    </div>
  );
};

const OnboardingScreen = ({ token, userId, name, onDone }) => {
  const [step, setStep] = useState(0);
  const [level, setLevel] = useState("");
  const [field, setField] = useState("");
  const [goals, setGoals] = useState([]);
  const [mood, setMood] = useState("Motivé·e");
  const [bio, setBio] = useState("");
  const [loading, setLoading] = useState(false);
  const toggleGoal = g => setGoals(gs => gs.includes(g) ? gs.filter(x => x !== g) : gs.length < 3 ? [...gs, g] : gs);
  const finish = async () => {
    setLoading(true);
    try {
      await api(`profiles?id=eq.${userId}`, { method: "PATCH", token, body: JSON.stringify({ level: `${level} ${field}`, goals, mood, bio }) });
      onDone();
    } catch (e) { console.error(e); }
    setLoading(false);
  };
  const steps = [
    <div key="s0">
      <h2 style={{ margin: "0 0 6px", fontSize: 20, fontWeight: 700, color: C.text }}>Ton niveau</h2>
      <p style={{ margin: "0 0 20px", color: C.grayT, fontSize: 14 }}>Pour trouver les bons binômes</p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 20 }}>
        {LEVELS.map(l => <button key={l} onClick={() => setLevel(l)} style={{ padding: "10px", borderRadius: 10, border: `1.5px solid ${level === l ? C.navy : C.grayM}`, background: level === l ? C.navy : C.white, color: level === l ? "#fff" : C.text, fontWeight: level === l ? 600 : 400, fontSize: 14, cursor: "pointer" }}>{l}</button>)}
      </div>
      <p style={{ margin: "0 0 10px", fontSize: 14, fontWeight: 500, color: C.textS }}>Ta filière</p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
        {FIELDS.map(f => <button key={f} onClick={() => setField(f)} style={{ padding: "8px 14px", borderRadius: 20, border: `1.5px solid ${field === f ? C.teal : C.grayM}`, background: field === f ? C.tealL : C.white, color: field === f ? C.teal : C.textS, fontWeight: field === f ? 600 : 400, fontSize: 13, cursor: "pointer" }}>{f}</button>)}
      </div>
      <button onClick={() => setStep(1)} style={{ width: "100%", background: level && field ? C.navy : C.gray, color: level && field ? "#fff" : C.grayT, border: "none", borderRadius: 12, padding: "13px", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>Continuer</button>
    </div>,
    <div key="s1">
      <h2 style={{ margin: "0 0 6px", fontSize: 20, fontWeight: 700, color: C.text }}>Tes objectifs</h2>
      <p style={{ margin: "0 0 20px", color: C.grayT, fontSize: 14 }}>Choisis jusqu'à 3 objectifs</p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
        {GOALS_OPTIONS.map(g => <button key={g} onClick={() => toggleGoal(g)} style={{ padding: "9px 16px", borderRadius: 20, border: `1.5px solid ${goals.includes(g) ? C.teal : C.grayM}`, background: goals.includes(g) ? C.tealL : C.white, color: goals.includes(g) ? C.teal : C.textS, fontWeight: goals.includes(g) ? 600 : 400, fontSize: 13, cursor: "pointer" }}>{g}</button>)}
      </div>
      <button onClick={() => setStep(2)} style={{ width: "100%", background: goals.length > 0 ? C.navy : C.gray, color: goals.length > 0 ? "#fff" : C.grayT, border: "none", borderRadius: 12, padding: "13px", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>Continuer</button>
    </div>,
    <div key="s2">
      <h2 style={{ margin: "0 0 6px", fontSize: 20, fontWeight: 700, color: C.text }}>Comment tu te sens ?</h2>
      <p style={{ margin: "0 0 20px", color: C.grayT, fontSize: 14 }}>Ton humeur du jour</p>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
        {Object.entries(MOODS).map(([m, col]) => <button key={m} onClick={() => setMood(m)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", borderRadius: 12, border: `1.5px solid ${mood === m ? col : C.grayM}`, background: mood === m ? col + "15" : C.white, cursor: "pointer" }}>
          <span style={{ width: 10, height: 10, borderRadius: "50%", background: col }} />
          <span style={{ fontSize: 14, fontWeight: mood === m ? 600 : 400, color: mood === m ? col : C.text }}>{m}</span>
          {mood === m && <i className="ti ti-check" style={{ marginLeft: "auto", color: col, fontSize: 16 }} />}
        </button>)}
      </div>
      <div style={{ marginBottom: 16 }}>
        <p style={{ margin: "0 0 8px", fontSize: 13, fontWeight: 500, color: C.textS }}>Un mot sur toi (optionnel)</p>
        <textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Ex: Dispo les matins, j'aime travailler en Pomodoro..." style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1.5px solid ${C.grayM}`, fontSize: 14, color: C.text, background: C.gray, outline: "none", resize: "none", height: 80, fontFamily: "inherit", boxSizing: "border-box" }} />
      </div>
      <button onClick={finish} disabled={loading} style={{ width: "100%", background: C.navy, color: "#fff", border: "none", borderRadius: 12, padding: "13px", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>{loading ? "Création..." : "Créer mon profil"}</button>
    </div>
  ];
  return (
    <div style={{ flex: 1, overflowY: "auto", padding: "32px 24px 24px" }}>
      <div style={{ display: "flex", gap: 6, marginBottom: 28 }}>
        {[0, 1, 2].map(i => <div key={i} style={{ flex: 1, height: 4, borderRadius: 2, background: i <= step ? C.navy : C.grayM, transition: "background 0.3s" }} />)}
      </div>
      {steps[step]}
    </div>
  );
};

const Accueil = ({ profile }) => {
  const [objs, setObjs] = useState([
    { lb: "Réviser 1h (Pomodoro x2)", done: false },
    { lb: "Relire mes fiches du jour", done: false },
    { lb: "Faire 20 flashcards", done: false },
    { lb: "Message à mon binôme", done: false },
  ]);
  const done = objs.filter(o => o.done).length;
  const firstName = (profile?.name || "Sofia").split(" ")[0];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Bonjour" : hour < 18 ? "Bon après-midi" : "Bonsoir";
  return (
    <div style={{ padding: "20px 16px", overflowY: "auto", flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <p style={{ fontSize: 12, color: C.grayT, margin: "0 0 2px" }}>{new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</p>
          <h1 style={{ fontSize: 24, fontWeight: 600, color: C.text, margin: 0, lineHeight: 1.2 }}>{greeting},<br />{firstName}</h1>
        </div>
        <Av name={profile?.name || "S"} sz={42} />
      </div>
      <p style={{ fontSize: 11, fontWeight: 600, color: C.grayT, letterSpacing: "0.08em", margin: "0 0 10px" }}>TA PRIORITÉ DU JOUR</p>
      <div style={{ background: C.orangeL, border: "1px solid #F5D5A8", borderRadius: 14, padding: 14, marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <p style={{ margin: 0, fontWeight: 600, fontSize: 14, color: "#B86A10" }}>Objectifs du jour</p>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#B86A10" }}>{done}/4</span>
        </div>
        <div style={{ background: C.grayM, borderRadius: 4, height: 6, marginBottom: 12 }}>
          <div style={{ height: 6, borderRadius: 4, background: C.orange, width: `${(done / 4) * 100}%`, transition: "width 0.3s" }} />
        </div>
        {objs.map((o, i) => (
          <button key={i} onClick={() => setObjs(os => os.map((ob, j) => j === i ? { ...ob, done: !ob.done } : ob))} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, background: "none", border: "none", cursor: "pointer", padding: "7px 0", textAlign: "left" }}>
            <div style={{ width: 20, height: 20, borderRadius: 6, border: `2px solid ${o.done ? C.orange : C.grayM}`, background: o.done ? C.orange : "none", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
              {o.done && <i className="ti ti-check" style={{ fontSize: 12, color: "#fff" }} />}
            </div>
            <span style={{ fontSize: 13, color: o.done ? C.grayT : C.text, textDecoration: o.done ? "line-through" : "none" }}>{o.lb}</span>
          </button>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
        <div style={{ background: "#EEF3FF", borderRadius: 14, padding: "16px 14px" }}>
          <i className="ti ti-book" style={{ fontSize: 22, color: C.navy, display: "block", marginBottom: 8 }} />
          <p style={{ margin: "0 0 3px", fontWeight: 500, color: C.navy, fontSize: 14 }}>Réviser</p>
          <p style={{ margin: 0, fontSize: 11, color: "#6B7FC4" }}>Bientôt disponible</p>
        </div>
        <div style={{ background: C.tealL, borderRadius: 14, padding: "16px 14px" }}>
          <i className="ti ti-users" style={{ fontSize: 22, color: C.teal, display: "block", marginBottom: 8 }} />
          <p style={{ margin: "0 0 3px", fontWeight: 500, color: C.teal, fontSize: 14 }}>Découvrir</p>
          <p style={{ margin: 0, fontSize: 11, color: "#2D9E7A99" }}>Binômes & projets</p>
        </div>
      </div>
      <div style={{ background: C.navy, borderRadius: 14, overflow: "hidden" }}>
        <div style={{ background: C.navyL, height: 70, display: "flex", alignItems: "flex-end", padding: "8px 14px", marginBottom: 10 }}>
          <span style={{ background: "rgba(255,255,255,0.15)", color: "#fff", fontSize: 10, fontWeight: 600, padding: "3px 8px", borderRadius: 6 }}>NANTES UNIVERSITÉ</span>
        </div>
        <div style={{ padding: "0 14px 14px" }}>
          <p style={{ margin: "0 0 4px", color: "#fff", fontWeight: 500, fontSize: 15, lineHeight: 1.3 }}>Fundeya est lancé — rejoins la communauté !</p>
          <p style={{ margin: 0, color: "rgba(255,255,255,0.55)", fontSize: 12 }}>Équipe Fundeya · Aujourd'hui</p>
        </div>
      </div>
    </div>
  );
};

const Decouvrir = ({ token, userId }) => {
  const [profiles, setProfiles] = useState([]);
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("Tous");
  useEffect(() => {
    const load = async () => {
      try {
        const [ps, cs] = await Promise.all([
          api(`profiles?id=neq.${userId}&limit=20`),
          api(`connections?user_id=eq.${userId}`, { token }),
        ]);
        setProfiles(ps || []);
        setConnections((cs || []).map(c => c.connected_to));
      } catch (e) { console.error(e); }
      setLoading(false);
    };
    load();
  }, []);
  const connect = async (targetId) => {
    if (connections.includes(targetId)) return;
    try {
      await api("connections", { method: "POST", token, body: JSON.stringify({ user_id: userId, connected_to: targetId }) });
      setConnections(c => [...c, targetId]);
    } catch (e) { console.error(e); }
  };
  const scored = profiles.map((p, i) => ({ ...p, affinity: 70 + ((p.name.charCodeAt(0) + i) % 25) })).sort((a, b) => b.affinity - a.affinity);
  const top = scored[0];
  const rest = scored.slice(1);
  return (
    <div style={{ overflowY: "auto", flex: 1 }}>
      <div style={{ padding: "20px 16px 0", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div><h2 style={{ margin: 0, fontSize: 20, fontWeight: 600, color: C.text }}>Fundeya</h2><p style={{ margin: 0, fontSize: 12, color: C.grayT }}>Nantes Université</p></div>
      </div>
      <div style={{ padding: "0 16px", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.gray, borderRadius: 10, padding: "9px 12px" }}>
          <i className="ti ti-search" style={{ color: C.grayT, fontSize: 16 }} />
          <span style={{ fontSize: 14, color: C.grayT }}>Rechercher un nom, une filière...</span>
        </div>
      </div>
      <div style={{ padding: "0 16px", marginBottom: 14, display: "flex", gap: 8 }}>
        {["Tous", "Révisions", "Projets", "Apprendre"].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ background: filter === f ? C.teal : "none", color: filter === f ? "#fff" : C.textS, border: `1px solid ${filter === f ? C.teal : C.grayM}`, borderRadius: 20, padding: "5px 14px", fontSize: 13, cursor: "pointer" }}>{f}</button>
        ))}
      </div>
      {loading ? (
        <div style={{ padding: "40px", textAlign: "center", color: C.grayT }}>Chargement des profils...</div>
      ) : profiles.length === 0 ? (
        <div style={{ padding: "40px 24px", textAlign: "center" }}>
          <i className="ti ti-users-plus" style={{ fontSize: 40, color: C.grayT, display: "block", marginBottom: 12 }} />
          <p style={{ color: C.grayT, fontSize: 14, margin: "0 0 6px" }}>Pas encore d'autres étudiants</p>
          <p style={{ color: C.grayT, fontSize: 12, margin: 0 }}>Partage Fundeya à tes collègues !</p>
        </div>
      ) : (
        <div style={{ padding: "0 16px" }}>
          {top && (
            <div style={{ background: C.navy, borderRadius: 16, padding: 16, marginBottom: 14 }}>
              <p style={{ margin: "0 0 12px", fontSize: 11, fontWeight: 600, color: C.orange, letterSpacing: "0.08em" }}>★ TA MEILLEURE AFFINITÉ</p>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                <Av name={top.name} sz={48} />
                <div style={{ flex: 1 }}>
                  <p style={{ margin: "0 0 2px", color: "#fff", fontWeight: 600, fontSize: 16 }}>{top.name}</p>
                  <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.65)", fontSize: 12 }}>{top.level || "Étudiant·e"}</p>
                  <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                    <div style={{ width: 7, height: 7, borderRadius: "50%", background: MOODS[top.mood] || C.orange }} />
                    <span style={{ fontSize: 12, color: "rgba(255,255,255,0.65)" }}>{top.mood || "Motivé·e"}</span>
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ margin: 0, fontSize: 28, fontWeight: 700, color: C.orange }}>{top.affinity}%</p>
                  <p style={{ margin: 0, fontSize: 10, color: "rgba(255,255,255,0.5)" }}>AFFINITÉ</p>
                </div>
              </div>
              {top.goals?.length > 0 && <p style={{ margin: "0 0 14px", fontSize: 13, color: "rgba(255,255,255,0.7)" }}>{top.goals.join(" · ")}</p>}
              <button onClick={() => connect(top.id)} style={{ width: "100%", background: connections.includes(top.id) ? C.teal : "#fff", border: "none", borderRadius: 10, padding: "11px", fontSize: 14, fontWeight: 600, color: connections.includes(top.id) ? "#fff" : C.navy, cursor: "pointer" }}>{connections.includes(top.id) ? "✓ Connecté·e" : "Envoyer un message"}</button>
            </div>
          )}
          {rest.length > 0 && <>
            <p style={{ fontSize: 11, fontWeight: 600, color: C.grayT, letterSpacing: "0.08em", margin: "0 0 10px" }}>AUTRES SUGGESTIONS</p>
            {rest.map((u) => (
              <div key={u.id} style={{ background: C.white, border: `1px solid ${C.grayM}`, borderRadius: 14, padding: 14, marginBottom: 10 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                  <Av name={u.name} sz={40} />
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: "0 0 2px", fontWeight: 500, fontSize: 14, color: C.text }}>{u.name}</p>
                    <p style={{ margin: 0, fontSize: 12, color: C.grayT }}>{u.level || "Étudiant·e"}</p>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <p style={{ margin: 0, fontSize: 18, fontWeight: 700, color: C.grayT }}>{u.affinity}%</p>
                    <p style={{ margin: 0, fontSize: 10, color: C.grayT }}>AFFINITÉ</p>
                  </div>
                </div>
                {u.goals?.length > 0 && <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>{u.goals.slice(0, 2).map((g, j) => <span key={j} style={{ background: C.tealL, color: C.teal, fontSize: 12, padding: "4px 10px", borderRadius: 20, fontWeight: 500 }}>{g}</span>)}</div>}
                <button onClick={() => connect(u.id)} style={{ width: "100%", background: connections.includes(u.id) ? C.teal : C.navy, border: "none", borderRadius: 10, padding: "10px", fontSize: 14, fontWeight: 500, color: "#fff", cursor: "pointer" }}>{connections.includes(u.id) ? "✓ Connecté·e" : "Se connecter"}</button>
              </div>
            ))}
          </>}
          <div style={{ height: 16 }} />
        </div>
      )}
    </div>
  );
};

const MessagesScreen = ({ token, userId }) => {
  const [convs, setConvs] = useState([]);
  const [open, setOpen] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const bottomRef = useRef(null);
  useEffect(() => {
    const load = async () => {
      try {
        const cs = await api(`connections?user_id=eq.${userId}`, { token });
        if (!cs?.length) { setLoading(false); return; }
        const ids = cs.map(c => c.connected_to);
        const ps = await api(`profiles?id=in.(${ids.join(",")})`);
        setConvs(ps || []);
      } catch (e) { console.error(e); }
      setLoading(false);
    };
    load();
  }, []);
  const openConv = async (p) => {
    setOpen(p);
    try {
      const ms = await api(`messages?or=(and(sender_id.eq.${userId},receiver_id.eq.${p.id}),and(sender_id.eq.${p.id},receiver_id.eq.${userId}))&order=created_at.asc`, { token });
      setMsgs(ms || []);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
    } catch (e) { console.error(e); }
  };
  const send = async () => {
    if (!input.trim() || !open) return;
    const text = input.trim(); setInput("");
    const msg = { sender_id: userId, receiver_id: open.id, content: text, created_at: new Date().toISOString() };
    setMsgs(m => [...m, msg]);
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    try { await api("messages", { method: "POST", token, body: JSON.stringify(msg) }); } catch (e) { console.error(e); }
  };
  if (open) return (
    <div style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "hidden" }}>
      <div style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${C.grayM}`, flexShrink: 0 }}>
        <button onClick={() => setOpen(null)} style={{ background: "none", border: "none", cursor: "pointer", color: C.navy, padding: 0 }}><i className="ti ti-arrow-left" style={{ fontSize: 22 }} /></button>
        <Av name={open.name} sz={38} online />
        <div><p style={{ margin: 0, fontWeight: 600, fontSize: 15, color: C.text }}>{open.name}</p><p style={{ margin: 0, fontSize: 12, color: C.teal }}>{open.level || "Étudiant·e"}</p></div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "16px", display: "flex", flexDirection: "column", gap: 10 }}>
        {msgs.length === 0 && <div style={{ textAlign: "center", padding: "30px 0", color: C.grayT, fontSize: 13 }}>Dis bonjour à {open.name.split(" ")[0]} 👋</div>}
        {msgs.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.sender_id === userId ? "flex-end" : "flex-start" }}>
            <div style={{ maxWidth: "75%", background: m.sender_id === userId ? C.navy : C.gray, color: m.sender_id === userId ? "#fff" : C.text, borderRadius: m.sender_id === userId ? "16px 16px 4px 16px" : "16px 16px 16px 4px", padding: "10px 14px", fontSize: 14, lineHeight: 1.4 }}>{m.content}</div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div style={{ padding: "12px 16px", borderTop: `1px solid ${C.grayM}`, display: "flex", gap: 10, alignItems: "center", flexShrink: 0 }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Écrire un message..." style={{ flex: 1, padding: "10px 14px", borderRadius: 22, border: `1px solid ${C.grayM}`, fontSize: 14, background: C.gray, outline: "none" }} />
        <button onClick={send} style={{ width: 40, height: 40, borderRadius: "50%", background: C.navy, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><i className="ti ti-send" style={{ color: "#fff", fontSize: 16 }} /></button>
      </div>
    </div>
  );
  return (
    <div style={{ flex: 1, overflowY: "auto" }}>
      <div style={{ padding: "20px 16px 14px" }}>
        <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 600, color: C.text }}>Messages</h2>
        <p style={{ margin: 0, fontSize: 12, color: C.grayT }}>{convs.length} conversation{convs.length !== 1 ? "s" : ""}</p>
      </div>
      {loading ? <div style={{ padding: "40px", textAlign: "center", color: C.grayT }}>Chargement...</div>
        : convs.length === 0 ? (
          <div style={{ padding: "40px 24px", textAlign: "center" }}>
            <i className="ti ti-message-plus" style={{ fontSize: 40, color: C.grayT, display: "block", marginBottom: 12 }} />
            <p style={{ color: C.grayT, fontSize: 14, margin: "0 0 6px" }}>Pas encore de conversations</p>
            <p style={{ color: C.grayT, fontSize: 12, margin: 0 }}>Connecte-toi avec des étudiants dans Découvrir</p>
          </div>
        ) : convs.map(p => (
          <button key={p.id} onClick={() => openConv(p)} style={{ width: "100%", background: "none", border: "none", cursor: "pointer", padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${C.grayM}`, textAlign: "left" }}>
            <Av name={p.name} sz={44} online />
            <div style={{ flex: 1 }}>
              <p style={{ margin: "0 0 3px", fontWeight: 600, fontSize: 15, color: C.text }}>{p.name}</p>
              <p style={{ margin: 0, fontSize: 13, color: C.grayT }}>{p.level || "Étudiant·e"}</p>
            </div>
            <i className="ti ti-chevron-right" style={{ color: C.grayT, fontSize: 16 }} />
          </button>
        ))}
    </div>
  );
};

const ProfilScreen = ({ token, userId, profile, onLogout }) => {
  const [mood, setMood] = useState(profile?.mood || "Motivé·e");
  const [saving, setSaving] = useState(false);
  const [objs, setObjs] = useState([
    { lb: "Réviser 1h (Pomodoro x2)", done: false },
    { lb: "Relire mes fiches du jour", done: false },
    { lb: "Faire 20 flashcards", done: false },
    { lb: "Message à mon binôme", done: false },
  ]);
  const done = objs.filter(o => o.done).length;
  const saveMood = async (m) => {
    setMood(m); setSaving(true);
    try { await api(`profiles?id=eq.${userId}`, { method: "PATCH", token, body: JSON.stringify({ mood: m }) }); } catch (e) { console.error(e); }
    setSaving(false);
  };
  return (
    <div style={{ overflowY: "auto", flex: 1 }}>
      <div style={{ padding: "20px 16px", display: "flex", alignItems: "center", gap: 14 }}>
        <Av name={profile?.name || "?"} sz={62} />
        <div style={{ flex: 1 }}>
          <h2 style={{ margin: "0 0 2px", fontSize: 20, fontWeight: 600, color: C.text }}>{profile?.name || "Mon profil"}</h2>
          <p style={{ margin: "0 0 2px", fontSize: 13, color: C.teal, fontWeight: 500 }}>{profile?.level || "Étudiant·e"}</p>
          <p style={{ margin: 0, fontSize: 12, color: C.grayT }}>{profile?.university || "Nantes Université"}</p>
        </div>
        <button onClick={onLogout} title="Déconnexion" style={{ width: 36, height: 36, borderRadius: "50%", background: C.gray, border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <i className="ti ti-logout" style={{ fontSize: 16, color: C.textS }} />
        </button>
      </div>
      {profile?.goals?.length > 0 && <div style={{ padding: "0 16px", marginBottom: 16 }}><div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{profile.goals.map((g, i) => <span key={i} style={{ background: C.tealL, color: C.teal, fontSize: 12, padding: "5px 12px", borderRadius: 20, fontWeight: 500 }}>{g}</span>)}</div></div>}
      <div style={{ padding: "0 16px", marginBottom: 14 }}>
        <div style={{ background: C.white, border: `1px solid ${C.grayM}`, borderRadius: 14, padding: 14, marginBottom: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <p style={{ margin: 0, fontWeight: 500, fontSize: 14, color: C.text }}>Mon humeur {saving && <span style={{ fontSize: 11, color: C.grayT }}>· sauvegarde...</span>}</p>
            <span style={{ background: (MOODS[mood] || C.navy) + "20", color: MOODS[mood] || C.navy, fontSize: 12, fontWeight: 600, padding: "3px 10px", borderRadius: 20 }}>● {mood}</span>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
            {Object.entries(MOODS).map(([m, col]) => (
              <button key={m} onClick={() => saveMood(m)} style={{ background: mood === m ? col : "none", color: mood === m ? "#fff" : C.textS, border: `1.5px solid ${mood === m ? col : C.grayM}`, borderRadius: 20, padding: "5px 12px", fontSize: 12, cursor: "pointer", fontWeight: mood === m ? 600 : 400, display: "flex", alignItems: "center", gap: 5 }}>
                <span style={{ width: 7, height: 7, borderRadius: "50%", background: mood === m ? "#fff" : col, display: "inline-block" }} />{m}
              </button>
            ))}
          </div>
          {profile?.bio && <div style={{ marginTop: 12, background: C.gray, borderRadius: 8, padding: "9px 12px", fontSize: 13, color: C.textS }}>{profile.bio}</div>}
        </div>
        <div style={{ background: C.orangeL, border: "1px solid #F5D5A8", borderRadius: 14, padding: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <p style={{ margin: 0, fontWeight: 600, fontSize: 14, color: "#B86A10" }}>Objectifs du jour</p>
            <span style={{ fontSize: 13, fontWeight: 600, color: "#B86A10" }}>{done}/4</span>
          </div>
          <div style={{ background: C.grayM, borderRadius: 4, height: 6, marginBottom: 12 }}>
            <div style={{ height: 6, borderRadius: 4, background: C.orange, width: `${(done / 4) * 100}%`, transition: "width 0.3s" }} />
          </div>
          {objs.map((o, i) => (
            <button key={i} onClick={() => setObjs(os => os.map((ob, j) => j === i ? { ...ob, done: !ob.done } : ob))} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, background: "none", border: "none", cursor: "pointer", padding: "7px 0", textAlign: "left" }}>
              <div style={{ width: 20, height: 20, borderRadius: 6, border: `2px solid ${o.done ? C.orange : C.grayM}`, background: o.done ? C.orange : "none", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {o.done && <i className="ti ti-check" style={{ fontSize: 12, color: "#fff" }} />}
              </div>
              <span style={{ fontSize: 13, color: o.done ? C.grayT : C.text, textDecoration: o.done ? "line-through" : "none" }}>{o.lb}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [screen, setScreen] = useState("auth");
  const [active, setActive] = useState("accueil");
  const onAuth = async (tk, u, nameHint) => {
    setToken(tk); setUser(u);
    try {
      const ps = await api(`profiles?id=eq.${u.id}`, { token: tk });
      if (ps?.length && ps[0].level) { setProfile(ps[0]); setScreen("app"); }
      else { setProfile(ps?.[0] || { id: u.id, name: nameHint || u.email }); setScreen("onboarding"); }
    } catch (e) { setScreen("onboarding"); }
  };
  const onOnboardingDone = async () => {
    try { const ps = await api(`profiles?id=eq.${user.id}`, { token }); setProfile(ps?.[0]); } catch (e) { }
    setScreen("app");
  };
  const logout = () => { setToken(null); setUser(null); setProfile(null); setScreen("auth"); setActive("accueil"); };
  const appScreens = {
    accueil: <Accueil profile={profile} />,
    decouvrir: <Decouvrir token={token} userId={user?.id} />,
    messages: <MessagesScreen token={token} userId={user?.id} />,
    profil: <ProfilScreen token={token} userId={user?.id} profile={profile} onLogout={logout} />,
  };
  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh", background: "#E8EAF0", padding: "20px 0" }}>
      <div style={{ width: 375, height: 780, background: C.white, borderRadius: 40, overflow: "hidden", display: "flex", flexDirection: "column", boxShadow: "0 20px 60px rgba(0,0,0,0.18)" }}>
        <div style={{ background: C.white, padding: "14px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
          <span style={{ fontSize: 13, fontWeight: 500, color: C.text }}>9:41</span>
          <div style={{ width: 60, height: 20, background: C.text, borderRadius: 10 }} />
          <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
            <i className="ti ti-wifi" style={{ fontSize: 14, color: C.text }} />
            <i className="ti ti-battery-2" style={{ fontSize: 16, color: C.text }} />
          </div>
        </div>
        <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          {screen === "auth" && <AuthScreen onAuth={onAuth} />}
          {screen === "onboarding" && <OnboardingScreen token={token} userId={user?.id} name={profile?.name} onDone={onOnboardingDone} />}
          {screen === "app" && appScreens[active]}
        </div>
        {screen === "app" && <Nav active={active} set={setActive} />}
      </div>
    </div>
  );
}
